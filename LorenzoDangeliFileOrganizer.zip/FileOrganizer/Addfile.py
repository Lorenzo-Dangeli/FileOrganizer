import os
import shutil
import csv
import argparse

def main():
    # Configurazione dell'argomento da riga di comando (CLI)
    parser = argparse.ArgumentParser(description="Sposta un singolo file nella sua sottocartella e aggiorna il recap.csv")
    parser.add_argument("filename", type=str, help="Il nome del file da spostare (es. trump.jpeg)")
    
    args = parser.parse_args()
    nome_file = args.filename
    
    cartella_origine = "files"
    path_file = os.path.join(cartella_origine, nome_file)
    file_recap = "recap.csv"

    # 1. Verifico se il file esiste nella cartella di origine
    if not os.path.exists(path_file):
        print(f"Errore: Il file '{nome_file}' non esiste nella cartella '{cartella_origine}'.")
        return

    # 2. Classifico il file in base all'estensione
    estensione = nome_file.lower().split('.')[-1]

    if estensione in ["mp3", "wav"]:
        tipo = "audio"
        destinazione = os.path.join(cartella_origine, "audio")
    elif estensione in ["txt", "odt", "pdf", "docx"]:
        tipo = "doc"
        destinazione = os.path.join(cartella_origine, "docs")
    elif estensione in ["png", "jpg", "jpeg"]:
        tipo = "image"
        destinazione = os.path.join(cartella_origine, "images")
    else:
        print(f"Errore: Estensione non riconosciuta per il file '{nome_file}'.")
        return

    # 3. Creo la sottocartella se non esiste
    os.makedirs(destinazione, exist_ok=True)

    # 4. Calcolo la dimensione in byte e spostiamo il file
    dimensione_byte = os.path.getsize(path_file)
    shutil.move(path_file, os.path.join(destinazione, nome_file))

    # 5. Aggiorno il file recap.csv aggiungendo la riga in coda (modalità 'a')
    with open(file_recap, mode="a", newline="", encoding="utf-8") as f_recap:
        writer = csv.writer(f_recap)
        writer.writerow([nome_file, tipo, dimensione_byte])

    print(f"Successo! File '{nome_file}' spostato nella cartella '{tipo}' ({dimensione_byte} bytes) e recap.csv aggiornato.")

if __name__ == "__main__":
    main()